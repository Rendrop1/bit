<?
$sSectionName = "Вход на сайт";
$arDirProperties = array(

);
?>